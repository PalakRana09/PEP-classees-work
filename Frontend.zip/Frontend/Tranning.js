document.write(" I am Paragraph");

window.alert("Hello, World!");

var wifi = 'Testing'
document.write(wifi);