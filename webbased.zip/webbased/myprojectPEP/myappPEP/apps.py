from django.apps import AppConfig


class MyapppepConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myappPEP'
